﻿namespace _5
{
    public static class GlobalConstants
    {
        public const string InvalidNameErrorMessage = "A name should not be empty.";
    }
}
