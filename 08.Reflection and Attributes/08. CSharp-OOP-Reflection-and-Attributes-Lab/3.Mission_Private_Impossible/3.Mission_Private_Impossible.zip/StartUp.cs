﻿using System;

namespace _3.Mission_Private_Impossible
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
