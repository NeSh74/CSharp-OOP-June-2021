﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _4.Collector
{
    class Spy
    {
    }
}
