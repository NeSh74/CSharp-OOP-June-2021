﻿namespace PersonInfo
{
    public interface IRebel : IPerson
    {
        string Group { get; }
    }
}
