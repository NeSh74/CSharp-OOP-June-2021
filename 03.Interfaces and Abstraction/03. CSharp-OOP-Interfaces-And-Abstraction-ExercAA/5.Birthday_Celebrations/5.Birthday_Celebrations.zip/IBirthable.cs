﻿namespace PersonInfo
{
    public interface IBirthable
    {
        string BirthDate { get; }
    }
}
