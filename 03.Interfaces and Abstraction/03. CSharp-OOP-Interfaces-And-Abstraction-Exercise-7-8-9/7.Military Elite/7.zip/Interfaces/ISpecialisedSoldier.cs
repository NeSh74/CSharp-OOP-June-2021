﻿namespace MilitaryElite.Interfaces
{
    using MilitaryElite.Enumerations;

    public interface ISpecialisedSoldier
    {
        public SoldierCorpEnum SoldierCorp { get; }
    }
}
