﻿namespace MilitaryElite.Interfaces
{
    public interface IPrivate
    {
        public decimal Salary { get; }
    }
}
