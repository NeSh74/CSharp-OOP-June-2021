﻿namespace CollectionHierarchy.Contracts
{
    public interface IAddCollection
    {
        int Add(string item);
    }
}